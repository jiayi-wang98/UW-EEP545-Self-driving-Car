#!/usr/bin/env python

import rospy
import numpy as np
from geometry_msgs.msg import PoseStamped
import Utils # <----------- LOOK AT THESE FUNCTIONS ***************************

SUB_TOPIC = '/car/car_pose' # The topic that provides the simulated car pose
PUB_TOPIC = '/clone_follower_pose/pose' # The topic that you should publish to
MAP_TOPIC = '/static_map' # The service topic that will provide the map


# Follows the simulated robot around
class CloneFollower:

  '''
  Initializes a CloneFollower object
  In:
    follow_offset: The required x offset between the robot and its clone follower
    force_in_bounds: Whether the clone should toggle between following in front
                     and behind when it goes out of bounds of the map
  '''
  def __init__(self, follow_offset, force_in_bounds):
    # YOUR CODE HERE 
    self.follow_offset = follow_offset # Store the input params in self
    self.force_in_bounds = force_in_bounds # Store the input params in self
    self.map_img, self.map_info = Utils.get_map(MAP_TOPIC)# Get and store the map
                                  # for bounds checking
    
    # Setup publisher that publishes to PUB_TOPIC
    self.pub = rospy.Publisher(PUB_TOPIC, PoseStamped , queue_size=100)
    
    # Setup subscriber that subscribes to SUB_TOPIC and uses the self.update_pose
    # callback
    self.sub = rospy.Subscriber(SUB_TOPIC,PoseStamped, self.update_pose)
    
  '''
  Given the translation and rotation between the robot and map, computes the pose
  of the clone
  (This function is optional)
  In:
    trans: The translation between the robot and map
    rot: The rotation between the robot and map
  Out:
    The pose of the clone
  '''
  def compute_follow_pose(self, trans, rot):
    # YOUR CODE HERE
    theta=Utils.quaternion_to_angle(rot)
    x_offset=self.follow_offset*np.cos(theta)
    y_offset=self.follow_offset*np.sin(theta)
    x=trans.x+x_offset
    y=trans.y+y_offset

    return [x, y, theta]
  '''
  Callback that runs each time a sim pose is received. Should publish an updated
  pose of the clone.
  In:
    msg: The pose of the simulated car. Should be a geometry_msgs/PoseStamped
  '''  
  def update_pose(self, msg):
    # YOUR CODE HERE
    pose_B = self.compute_follow_pose(msg.pose.position, msg.pose.orientation)

    # Check bounds if required
    # Compute the pose of the clone
    # Note: To convert from a message quaternion to corresponding rotation matrix,
    #       look at the functions in Utils.py
    
    # Check bounds if required
    if self.force_in_bounds:
      # Functions in Utils.py will again be useful here
      pose_in_map = Utils.world_to_map (pose_B, self.map_info)

      if self.map_img[pose_in_map[1]][pose_in_map[0]] == 0: #mag_img[x][y]=1 means there is space to go, mag_img[x][y]=0 means there is a wall.
        self.follow_offset = -self.follow_offset
	
	#recalculate the pose_B
        pose_B = self.compute_follow_pose(msg.pose.position, msg.pose.orientation)
      
    # Setup the out going PoseStamped message
    '''
    	[geometry_msgs/PoseStamped]:
	std_msgs/Header header
  	 uint32 seq
  	 time stamp
  	 string frame_id
	geometry_msgs/Pose pose
  	 geometry_msgs/Point position
    	  float64 x
    	  float64 y
    	  float64 z
  	 geometry_msgs/Quaternion orientation
    	  float64 x
    	  float64 y
    	  float64 z
    	  float64 w

    '''
    pose_message=PoseStamped()
    pose_message.header.stamp=rospy.Time.now()
    pose_message.header.frame_id="/map"
    pose_message.pose.position.x=pose_B[0]
    pose_message.pose.position.y=pose_B[1]
    pose_message.pose.position.z=0
    pose_message.pose.orientation=Utils.angle_to_quaternion (pose_B[2])
    # Publish the clone's pose
    self.pub.publish (pose_message)    

    
if __name__ == '__main__':
  follow_offset = 1.0 # The offset between the robot and clone
  force_in_bounds = False # Whether or not map bounds should be enforced
  
  rospy.init_node('clone_follower', anonymous=True) # Initialize the node
  
  # Populate params with values passed by launch file
  follow_offset =rospy.get_param ('follow_offset') # YOUR CODE HERE
  force_in_bounds = rospy.get_param ('force_in_bounds')# YOUR CODE HERE
  
  cf = CloneFollower(follow_offset, force_in_bounds) # Create a clone follower
  rospy.spin() # Spin
  
